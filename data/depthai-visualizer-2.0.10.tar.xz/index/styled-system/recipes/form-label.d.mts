/* eslint-disable */
import type { ConditionalValue } from '../types/index.d.mts';
import type { DistributiveOmit, Pretty } from '../types/system-types.d.mts';

interface FormLabelVariant {
  
}

type FormLabelVariantMap = {
  [key in keyof FormLabelVariant]: Array<FormLabelVariant[key]>
}

export type FormLabelVariantProps = {
  [key in keyof FormLabelVariant]?: ConditionalValue<FormLabelVariant[key]> | undefined
}

export interface FormLabelRecipe {
  __type: FormLabelVariantProps
  (props?: FormLabelVariantProps): string
  raw: (props?: FormLabelVariantProps) => FormLabelVariantProps
  variantMap: FormLabelVariantMap
  variantKeys: Array<keyof FormLabelVariant>
  splitVariantProps<Props extends FormLabelVariantProps>(props: Props): [FormLabelVariantProps, Pretty<DistributiveOmit<Props, keyof FormLabelVariantProps>>]
  getVariantProps: (props?: FormLabelVariantProps) => FormLabelVariantProps
}

/**
 * Styles for the FormLabel component


 */
export declare const formLabel: FormLabelRecipe