/* eslint-disable */
import type { ConditionalValue } from '../types/index.d.mts';
import type { DistributiveOmit, Pretty } from '../types/system-types.d.mts';

interface CardFooterVariant {
  
}

type CardFooterVariantMap = {
  [key in keyof CardFooterVariant]: Array<CardFooterVariant[key]>
}

export type CardFooterVariantProps = {
  [key in keyof CardFooterVariant]?: ConditionalValue<CardFooterVariant[key]> | undefined
}

export interface CardFooterRecipe {
  __type: CardFooterVariantProps
  (props?: CardFooterVariantProps): string
  raw: (props?: CardFooterVariantProps) => CardFooterVariantProps
  variantMap: CardFooterVariantMap
  variantKeys: Array<keyof CardFooterVariant>
  splitVariantProps<Props extends CardFooterVariantProps>(props: Props): [CardFooterVariantProps, Pretty<DistributiveOmit<Props, keyof CardFooterVariantProps>>]
  getVariantProps: (props?: CardFooterVariantProps) => CardFooterVariantProps
}

/**
 * Styles for the CardFooter component


 */
export declare const cardFooter: CardFooterRecipe