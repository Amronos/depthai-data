/* eslint-disable */
import type { FunctionComponent } from 'react'
import type { CqProperties } from '../patterns/cq.d.mts';
import type { HTMLStyledProps } from '../types/jsx.d.mts';
import type { DistributiveOmit } from '../types/system-types.d.mts';

export interface CqProps extends CqProperties, DistributiveOmit<HTMLStyledProps<'div'>, keyof CqProperties > {}


export declare const Cq: FunctionComponent<CqProps>