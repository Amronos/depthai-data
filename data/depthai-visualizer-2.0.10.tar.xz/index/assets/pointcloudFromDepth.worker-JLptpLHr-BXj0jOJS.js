const pe=Symbol("Comlink.proxy"),Fe=Symbol("Comlink.endpoint"),Me=Symbol("Comlink.releaseProxy"),re=Symbol("Comlink.finalizer"),J=Symbol("Comlink.thrown"),ye=e=>typeof e=="object"&&e!==null||typeof e=="function",Ge={canHandle:e=>ye(e)&&e[pe],serialize(e){const{port1:t,port2:n}=new MessageChannel;return ie(e,t),[n,[n]]},deserialize(e){return e.start(),Re(e)}},Te={canHandle:e=>ye(e)&&J in e,serialize({value:e}){let t;return e instanceof Error?t={isError:!0,value:{message:e.message,name:e.name,stack:e.stack}}:t={isError:!1,value:e},[t,[]]},deserialize(e){throw e.isError?Object.assign(new Error(e.value.message),e.value):e.value}},be=new Map([["proxy",Ge],["throw",Te]]);function ze(e,t){for(const n of e)if(t===n||n==="*"||n instanceof RegExp&&n.test(t))return!0;return!1}function ie(e,t=globalThis,n=["*"]){t.addEventListener("message",function g(a){if(!a||!a.data)return;if(!ze(n,a.origin)){console.warn(`Invalid origin '${a.origin}' for comlink proxy`);return}const{id:f,type:m,path:o}=Object.assign({path:[]},a.data),d=(a.data.argumentList||[]).map(L);let s;try{const i=o.slice(0,-1).reduce((r,p)=>r[p],e),c=o.reduce((r,p)=>r[p],e);switch(m){case"GET":s=c;break;case"SET":i[o.slice(-1)[0]]=L(a.data.value),s=!0;break;case"APPLY":s=c.apply(i,d);break;case"CONSTRUCT":{const r=new c(...d);s=We(r)}break;case"ENDPOINT":{const{port1:r,port2:p}=new MessageChannel;ie(e,p),s=Ve(r,[r])}break;case"RELEASE":s=void 0;break;default:return}}catch(i){s={value:i,[J]:0}}Promise.resolve(s).catch(i=>({value:i,[J]:0})).then(i=>{const[c,r]=ee(i);t.postMessage(Object.assign(Object.assign({},c),{id:f}),r),m==="RELEASE"&&(t.removeEventListener("message",g),he(t),re in e&&typeof e[re]=="function"&&e[re]())}).catch(i=>{const[c,r]=ee({value:new TypeError("Unserializable return value"),[J]:0});t.postMessage(Object.assign(Object.assign({},c),{id:f}),r)})}),t.start&&t.start()}function ke(e){return e.constructor.name==="MessagePort"}function he(e){ke(e)&&e.close()}function Re(e,t){const n=new Map;return e.addEventListener("message",function(a){const{data:f}=a;if(!f||!f.id)return;const m=n.get(f.id);if(m)try{m(f)}finally{n.delete(f.id)}}),ae(e,n,[],t)}function Z(e){if(e)throw new Error("Proxy has been released and is not useable")}function Pe(e){return W(e,new Map,{type:"RELEASE"}).then(()=>{he(e)})}const Q=new WeakMap,$="FinalizationRegistry"in globalThis&&new FinalizationRegistry(e=>{const t=(Q.get(e)||0)-1;Q.set(e,t),t===0&&Pe(e)});function Le(e,t){const n=(Q.get(t)||0)+1;Q.set(t,n),$&&$.register(e,t,e)}function De(e){$&&$.unregister(e)}function ae(e,t,n=[],g=function(){}){let a=!1;const f=new Proxy(g,{get(m,o){if(Z(a),o===Me)return()=>{De(f),Pe(e),t.clear(),a=!0};if(o==="then"){if(n.length===0)return{then:()=>f};const d=W(e,t,{type:"GET",path:n.map(s=>s.toString())}).then(L);return d.then.bind(d)}return ae(e,t,[...n,o])},set(m,o,d){Z(a);const[s,i]=ee(d);return W(e,t,{type:"SET",path:[...n,o].map(c=>c.toString()),value:s},i).then(L)},apply(m,o,d){Z(a);const s=n[n.length-1];if(s===Fe)return W(e,t,{type:"ENDPOINT"}).then(L);if(s==="bind")return ae(e,t,n.slice(0,-1));const[i,c]=fe(d);return W(e,t,{type:"APPLY",path:n.map(r=>r.toString()),argumentList:i},c).then(L)},construct(m,o){Z(a);const[d,s]=fe(o);return W(e,t,{type:"CONSTRUCT",path:n.map(i=>i.toString()),argumentList:d},s).then(L)}});return Le(f,e),f}function Ye(e){return Array.prototype.concat.apply([],e)}function fe(e){const t=e.map(ee);return[t.map(n=>n[0]),Ye(t.map(n=>n[1]))]}const Ue=new WeakMap;function Ve(e,t){return Ue.set(e,t),e}function We(e){return Object.assign(e,{[pe]:!0})}function ee(e){for(const[t,n]of be)if(n.canHandle(e)){const[g,a]=n.serialize(e);return[{type:"HANDLER",name:t,value:g},a]}return[{type:"RAW",value:e},Ue.get(e)||[]]}function L(e){switch(e.type){case"HANDLER":return be.get(e.name).deserialize(e.value);case"RAW":return e.value}}function W(e,t,n,g){return new Promise(a=>{const f=Math.trunc(Math.random()*Number.MAX_SAFE_INTEGER).toString();t.set(f,a),e.start&&e.start(),e.postMessage(Object.assign({id:f},n),g)})}function ce(e,t,n,g,a,f){const m=t*n,o=m,d=m+m/4,s=f.byteLength/16,i=new ArrayBuffer(f.byteLength),c=new DataView(i),r=new DataView(f.buffer);for(let U=0;U<s;U++){var p,u,h;const v=U%g,O=Math.floor(U/g),_=Math.round(v*(t/g)),B=Math.round(O*(n/a));if(_>=t||B>=n)continue;const A=B*t+_,M=Math.floor(B/2)*(t/2)+Math.floor(_/2),F=(p=e[A])!==null&&p!==void 0?p:0,D=((u=e[o+M])!==null&&u!==void 0?u:128)-128,Y=((h=e[d+M])!==null&&h!==void 0?h:128)-128;let T=F+1.402*Y,z=F-.344136*D-.714136*Y,w=F+1.772*D;T=Math.min(255,Math.max(0,T)),z=Math.min(255,Math.max(0,z)),w=Math.min(255,Math.max(0,w));const l=U*16;c.setFloat32(l,r.getFloat32(l,!0),!0),c.setFloat32(l+4,r.getFloat32(l+4,!0),!0),c.setFloat32(l+8,r.getFloat32(l+8,!0),!0),c.setUint8(l+12,T),c.setUint8(l+13,z),c.setUint8(l+14,w),c.setUint8(l+15,255)}return new Uint8Array(i)}const de="viewer-debug-logs-enabled",ge=!1;class y{constructor(){}static get debugLogsEnabled(){if(y._debugLogsEnabled===null){if(typeof localStorage>"u")return y._debugLogsEnabled=ge,ge;const t=localStorage.getItem(de);y._debugLogsEnabled=t==="true"}return y._debugLogsEnabled}static set debugLogsEnabled(t){if(y._debugLogsEnabled=t,typeof localStorage>"u"){console.warn("cannot interact with localStorage in worker");return}localStorage.setItem(de,t?"true":"false")}log(t,...n){y.debugLogsEnabled&&console.log(t,...n)}info(t,...n){y.debugLogsEnabled&&console.log(t,...n)}debug(t,...n){y.debugLogsEnabled&&console.debug(t,...n)}warn(t,...n){y.debugLogsEnabled&&console.warn(t,...n)}error(t,...n){y.debugLogsEnabled&&console.error(t,...n)}static getLogger(){return y.instance||(y.instance=new y),y.instance}}y.instance=null;y._debugLogsEnabled=null;const C=y.getLogger();function me(e,t,n,g,a,f){const m=t*n,o=new Float32Array(m*3);for(let r=0;r<n;r++)for(let p=0;p<t;p++){var d;const u=r*t+p,h=(d=e[u])!==null&&d!==void 0?d:0;let U=0,v=0,O=0;const B=h*1;if(B>0&&g!==0&&a!==0){const M=t*.5,F=n*.5;U=(p-M)*B/g,v=(r-F)*B/a,O=B,O>f&&(U=0,v=0,O=0)}const A=u*3;o[A]=U,o[A+1]=v,o[A+2]=O}const s=new ArrayBuffer(m*16),i=new DataView(s),c=new Uint8Array(o.buffer);for(let r=0;r<m;r++){const p=r*12,u=r*16;for(let h=0;h<12;++h)i.setUint8(u+h,c[p+h]);i.setUint8(u+12,0),i.setUint8(u+13,0),i.setUint8(u+14,0),i.setUint8(u+15,255)}return new Uint8Array(s)}const xe=128,He=16,Xe=`
struct Intrinsics {
  fx: f32,
  fy: f32,
  cx: f32,
  cy: f32,
  depthScale: f32,
  depthWidth: f32,
  depthHeight: f32,
  i420Width: f32,
  i420Height: f32,
  numFrames_f: f32,
  bytesPerI420Frame_f: f32,
  maxSteroDepth: f32,
};

struct OutputPointData {
  x: f32,
  y: f32,
  z: f32,
  color: u32,
};

@group(0) @binding(0) var<storage, read> depthBuffer: array<u32>;
@group(0) @binding(1) var<storage, read> intrinsics: Intrinsics;
@group(0) @binding(2) var<storage, read_write> xyzColorBuffer: array<OutputPointData>;
@group(0) @binding(3) var<storage, read> i420Buffer: array<u32>;

fn getI420Byte(byteIndexWithinFrame: u32, frameOffsetElements: u32, bufferLengthElements: u32) -> u32 {
  let globalByteIndex = (frameOffsetElements * 4u) + byteIndexWithinFrame;
  let elementIndex = globalByteIndex / 4u;
  let offsetInElement = globalByteIndex % 4u;
  if (elementIndex >= bufferLengthElements) {
    return 0u;
  }
  let packedValue = i420Buffer[elementIndex];
  return (packedValue >> (offsetInElement * 8u)) & 0xFFu;
}

@compute @workgroup_size(${xe}, 1, 1)
fn main(@builtin(global_invocation_id) global_id: vec3<u32>) {
  let pixel_idx_in_frame = global_id.x;
  let frame_idx = global_id.y;
  let depthWidth = u32(intrinsics.depthWidth);
  let depthHeight = u32(intrinsics.depthHeight);
  let i420WidthU = u32(intrinsics.i420Width);
  let i420HeightU = u32(intrinsics.i420Height);
  let numFrames = u32(intrinsics.numFrames_f);
  let bytesPerI420Frame = u32(intrinsics.bytesPerI420Frame_f);
  let numPixelsPerFrame = depthWidth * depthHeight;
  if (pixel_idx_in_frame >= numPixelsPerFrame || frame_idx >= numFrames || depthWidth == 0u || depthHeight == 0u) {
    return;
  }
  let global_output_idx = (frame_idx * numPixelsPerFrame) + pixel_idx_in_frame;
  let depth_elements_per_frame = (numPixelsPerFrame + 1u) / 2u;
  let depth_frame_offset = frame_idx * depth_elements_per_frame;
  let i420AlignedStrideBytes = (bytesPerI420Frame + 3u) / 4u * 4u;
  let i420_elements_per_frame_aligned = i420AlignedStrideBytes / 4u;
  let i420_frame_offset = frame_idx * i420_elements_per_frame_aligned;
  let depthIndex32_within_frame = pixel_idx_in_frame / 2u;
  let packedDepthU32_idx = depth_frame_offset + depthIndex32_within_frame;
  if (packedDepthU32_idx >= arrayLength(&depthBuffer)) {
    return;
  }
  let packedDepthU32 = depthBuffer[packedDepthU32_idx];
  var rawDepthU16: u32;
  if (pixel_idx_in_frame % 2u == 0u) {
    rawDepthU16 = packedDepthU32 & 0xFFFFu;
  } else {
    rawDepthU16 = (packedDepthU32 >> 16u) & 0xFFFFu;
  }
  let u = f32(pixel_idx_in_frame % depthWidth);
  let v = f32(pixel_idx_in_frame / depthWidth);
  var outputPoint: OutputPointData;
  outputPoint.x = 0.0;
  outputPoint.y = 0.0;
  outputPoint.z = 0.0;
  outputPoint.color = 0xFF000000u;
  let fx = intrinsics.fx;
  let fy = intrinsics.fy;
  let depthScale = intrinsics.depthScale;
  let maxSteroDepth = intrinsics.maxSteroDepth;
  if (rawDepthU16 > 0u && fx != 0.0 && fy != 0.0 && depthScale > 0.0) {
    let z = f32(rawDepthU16) * depthScale;
    let imageCenterX = f32(depthWidth) * 0.5;
    let imageCenterY = f32(depthHeight) * 0.5;
    let x = (u - imageCenterX) * z / fx;
    let y = (v - imageCenterY) * z / fy;
    
    // Filter out points beyond maxSteroDepth
    if (z <= maxSteroDepth) {
      outputPoint.x = x;
      outputPoint.y = y;
      outputPoint.z = z;
      
      if (i420WidthU > 0u && i420HeightU > 0u && bytesPerI420Frame > 0u) {
        let i420X = min(i420WidthU - 1u, u32(floor(u * (intrinsics.i420Width / intrinsics.depthWidth))));
        let i420Y = min(i420HeightU - 1u, u32(floor(v * (intrinsics.i420Height / intrinsics.depthHeight))));
        let frameSizeY = i420WidthU * i420HeightU;
        let uvWidth = (i420WidthU + 1u) / 2u;
        let uvHeight = (i420HeightU + 1u) / 2u;
        let frameSizeUV = uvWidth * uvHeight;
        let uOffsetBytes = frameSizeY;
        let vOffsetBytes = frameSizeY + frameSizeUV;
        let yIndexBytes = i420Y * i420WidthU + i420X;
        let uvX = i420X / 2u;
        let uvY = i420Y / 2u;
        let uvIndexBytes = uvY * uvWidth + uvX;
        let uIndexBytes = uOffsetBytes + uvIndexBytes;
        let vIndexBytes = vOffsetBytes + uvIndexBytes;
        let i420BufferTotalElements = arrayLength(&i420Buffer);
        if (yIndexBytes < bytesPerI420Frame && uIndexBytes < bytesPerI420Frame && vIndexBytes < bytesPerI420Frame && (i420_frame_offset + (vIndexBytes / 4u)) < i420BufferTotalElements) {
          let y_byte = getI420Byte(yIndexBytes, i420_frame_offset, i420BufferTotalElements);
          let u_byte = getI420Byte(uIndexBytes, i420_frame_offset, i420BufferTotalElements);
          let v_byte = getI420Byte(vIndexBytes, i420_frame_offset, i420BufferTotalElements);
          let y_f = f32(y_byte);
          let u_f = f32(u_byte) - 128.0;
          let v_f = f32(v_byte) - 128.0;
          var r_f = y_f + 1.402 * v_f;
          var g_f = y_f - 0.344136 * u_f - 0.714136 * v_f;
          var b_f = y_f + 1.772 * u_f;
          let r = u32(clamp(r_f, 0.0, 255.0)) & 0xFFu;
          let g = u32(clamp(g_f, 0.0, 255.0)) & 0xFFu;
          let b = u32(clamp(b_f, 0.0, 255.0)) & 0xFFu;
          let a = 255u;
          outputPoint.color = (r) | (g << 8u) | (b << 16u) | (a << 24u);
        }
      }
    }
  }
  if (global_output_idx < arrayLength(&xyzColorBuffer)) {
    xyzColorBuffer[global_output_idx] = outputPoint;
  }
}
`;async function Ne(e,t,n,g,a,f,m,o,d,s,i,{hasGPU:c}){const r=e.length;if(r===0||r!==o.length)return C.warn("GPU: Input frame arrays are empty or mismatched."),[];if(t<=0||n<=0)throw new Error("GPU: Invalid depth dimensions!");if(e[0]&&!(e[0]instanceof Uint16Array))throw new Error("GPU: depthFrames[0].data is NOT a Uint16Array!");if(o[0]&&!(o[0]instanceof Uint8Array))throw new Error("GPU: i420Frames[0].data is NOT a Uint8Array!");const p=1;if(!c){const w=[];for(let l=0;l<r;l++){const x=e[l],S=o[l];if(!x||!S){C.warn(`CPU Fallback: Skipping frame ${l} due to missing data.`),w.push(new Uint8Array(0));continue}try{const I=me(x,t,n,g,a,i);w.push(ce(S,d,s,t,n,I))}catch(I){C.error(`CPU Fallback: Error processing frame ${l}:`,I),w.push(new Uint8Array(0))}}return w}let u=null,h=null,U=null,v=null,O=null,_=null;try{var B,A;const w=await navigator.gpu.requestAdapter();if(!w)throw new Error("Failed to get GPU adapter.");u=await w.requestDevice();const l=u.queue,x=t*n,S=x*He,I=S*r,H=x*2,N=Math.ceil(H/4),we=N*r*4,q=(B=(A=o[0])===null||A===void 0?void 0:A.byteLength)!==null&&B!==void 0?B:0;if(q===0&&r>0)throw new Error("GPU: I420 frame data is empty or invalid for size calculation.");const X=Math.ceil(q/4)*4,Ee=X*r,j=new Float32Array([g,a,f,m,p,t,n,d,s,r,q,i]),_e=Math.max(j.byteLength,64);U=u.createBuffer({label:"Intrinsics Buffer",size:_e,usage:GPUBufferUsage.STORAGE|GPUBufferUsage.COPY_DST}),l.writeBuffer(U,0,j.buffer,j.byteOffset,j.byteLength),h=u.createBuffer({label:"Depth Buffer (Combined)",size:we,usage:GPUBufferUsage.STORAGE|GPUBufferUsage.COPY_DST,mappedAtCreation:!0});const Be=h.getMappedRange(),V=new Uint32Array(Be);for(let b=0;b<r;++b){const P=e[b];if(!P||!(P instanceof Uint16Array)){C.warn(`GPU: Skipping depth frame ${b} due to missing/invalid data.`);const E=b*N,k=N;V.fill(0,E,E+k);continue}const G=b*N;for(let E=0;E<x;E++){var M;const k=(M=P[E])!==null&&M!==void 0?M:0,R=G+Math.floor(E/2);if(R>=V.length)continue;E%2===0?V[R]=V[R]&4294901760|k:V[R]=V[R]&65535|k<<16}}h.unmap(),v=u.createBuffer({label:"I420 Buffer (Combined, Aligned)",size:Ee,usage:GPUBufferUsage.STORAGE|GPUBufferUsage.COPY_DST,mappedAtCreation:!0});const oe=v.getMappedRange(),se=new Uint8Array(oe);for(let b=0;b<r;++b){const P=o[b],G=b*X;if(!P||!(P instanceof Uint8Array)||P.byteLength!==q){C.warn(`GPU: Skipping I420 frame ${b} due to missing/invalid data or size mismatch.`),se.fill(0,G,G+X);continue}if(new Uint8Array(oe,G,P.byteLength).set(P),X>P.byteLength){const k=G+P.byteLength,R=X-P.byteLength;se.fill(0,k,k+R)}}v.unmap(),O=u.createBuffer({label:"Output XYZColor Buffer (Combined)",size:I,usage:GPUBufferUsage.STORAGE|GPUBufferUsage.COPY_SRC}),_=u.createBuffer({label:"Readback Buffer",size:I,usage:GPUBufferUsage.COPY_DST|GPUBufferUsage.MAP_READ});const ue=u.createBindGroupLayout({label:"Compute Bind Group Layout",entries:[{binding:0,visibility:GPUShaderStage.COMPUTE,buffer:{type:"read-only-storage"}},{binding:1,visibility:GPUShaderStage.COMPUTE,buffer:{type:"read-only-storage"}},{binding:2,visibility:GPUShaderStage.COMPUTE,buffer:{type:"storage"}},{binding:3,visibility:GPUShaderStage.COMPUTE,buffer:{type:"read-only-storage"}}]}),Se=u.createBindGroup({label:"Compute Bind Group",layout:ue,entries:[{binding:0,resource:{buffer:h}},{binding:1,resource:{buffer:U}},{binding:2,resource:{buffer:O}},{binding:3,resource:{buffer:v}}]}),ve=u.createShaderModule({label:"Compute Shader Module",code:Xe}),Oe=u.createComputePipeline({label:"Compute Pipeline",layout:u.createPipelineLayout({bindGroupLayouts:[ue]}),compute:{module:ve,entryPoint:"main"}}),te=u.createCommandEncoder({label:"Compute Command Encoder"}),K=te.beginComputePass({label:"Compute Pass"});K.setPipeline(Oe),K.setBindGroup(0,Se);const Ie=Math.ceil(x/xe),Ce=r;K.dispatchWorkgroups(Ie,Ce,1),K.end(),te.copyBufferToBuffer(O,0,_,0,I),l.submit([te.finish()]),await _.mapAsync(GPUMapMode.READ);const Ae=_.getMappedRange(),le=new Uint8Array(Ae.slice(0));_.unmap(),_=null;const ne=[];for(let b=0;b<r;b++){const P=b*S,G=Math.min(P+S,le.byteLength),E=le.slice(P,G);E.byteLength!==S?(C.warn(`GPU: Result frame ${b} has incorrect size (${E.byteLength} vs ${S}). Padding or error occurred.`),ne.push(new Uint8Array(S))):ne.push(E)}return ne}catch(w){C.error("GPU: Error during WebGPU processing:",w),C.warn("GPU: Falling back to CPU due to error.");const l=[];for(let x=0;x<r;x++){const S=e[x],I=o[x];if(!S||!I){C.warn(`CPU Fallback (error path): Skipping frame ${x} due to missing data.`),l.push(new Uint8Array(0));continue}try{const H=me(S,t,n,g,a,i);l.push(ce(I,d,s,t,n,H))}catch(H){C.error(`CPU Fallback (error path): Error processing frame ${x}:`,H),l.push(new Uint8Array(0))}}return l}finally{var F,D,Y,T,z;(F=h)===null||F===void 0||F.destroy(),(D=U)===null||D===void 0||D.destroy(),(Y=v)===null||Y===void 0||Y.destroy(),(T=O)===null||T===void 0||T.destroy(),(z=_)===null||z===void 0||z.destroy()}}ie({depthToPointcloudGPU:Ne});
