/**
 * @license
 * Copyright 2019 Google LLC
 * SPDX-License-Identifier: Apache-2.0
 */const ne=Symbol("Comlink.proxy"),Pe=Symbol("Comlink.endpoint"),Ue=Symbol("Comlink.releaseProxy"),$=Symbol("Comlink.finalizer"),Y=Symbol("Comlink.thrown"),ae=e=>typeof e=="object"&&e!==null||typeof e=="function",xe={canHandle:e=>ae(e)&&e[ne],serialize(e){const{port1:t,port2:r}=new MessageChannel;return j(e,t),[r,[r]]},deserialize(e){return e.start(),Se(e)}},we={canHandle:e=>ae(e)&&Y in e,serialize({value:e}){let t;return e instanceof Error?t={isError:!0,value:{message:e.message,name:e.name,stack:e.stack}}:t={isError:!1,value:e},[t,[]]},deserialize(e){throw e.isError?Object.assign(new Error(e.value.message),e.value):e.value}},ie=new Map([["proxy",xe],["throw",we]]);function Be(e,t){for(const r of e)if(t===r||r==="*"||r instanceof RegExp&&r.test(t))return!0;return!1}function j(e,t=globalThis,r=["*"]){t.addEventListener("message",function m(o){if(!o||!o.data)return;if(!Be(r,o.origin)){console.warn(`Invalid origin '${o.origin}' for comlink proxy`);return}const{id:u,type:d,path:l}=Object.assign({path:[]},o.data),c=(o.data.argumentList||[]).map(M);let f;try{const i=l.slice(0,-1).reduce((s,a)=>s[a],e),n=l.reduce((s,a)=>s[a],e);switch(d){case"GET":f=n;break;case"SET":i[l.slice(-1)[0]]=M(o.data.value),f=!0;break;case"APPLY":f=n.apply(i,c);break;case"CONSTRUCT":{const s=new n(...c);f=Ae(s)}break;case"ENDPOINT":{const{port1:s,port2:a}=new MessageChannel;j(e,a),f=Fe(s,[s])}break;case"RELEASE":f=void 0;break;default:return}}catch(i){f={value:i,[Y]:0}}Promise.resolve(f).catch(i=>({value:i,[Y]:0})).then(i=>{const[n,s]=H(i);t.postMessage(Object.assign(Object.assign({},n),{id:u}),s),d==="RELEASE"&&(t.removeEventListener("message",m),se(t),$ in e&&typeof e[$]=="function"&&e[$]())}).catch(i=>{const[n,s]=H({value:new TypeError("Unserializable return value"),[Y]:0});t.postMessage(Object.assign(Object.assign({},n),{id:u}),s)})}),t.start&&t.start()}function Ee(e){return e.constructor.name==="MessagePort"}function se(e){Ee(e)&&e.close()}function Se(e,t){const r=new Map;return e.addEventListener("message",function(o){const{data:u}=o;if(!u||!u.id)return;const d=r.get(u.id);if(d)try{d(u)}finally{r.delete(u.id)}}),q(e,r,[],t)}function L(e){if(e)throw new Error("Proxy has been released and is not useable")}function oe(e){return z(e,new Map,{type:"RELEASE"}).then(()=>{se(e)})}const V=new WeakMap,W="FinalizationRegistry"in globalThis&&new FinalizationRegistry(e=>{const t=(V.get(e)||0)-1;V.set(e,t),t===0&&oe(e)});function Ie(e,t){const r=(V.get(t)||0)+1;V.set(t,r),W&&W.register(e,t,e)}function ve(e){W&&W.unregister(e)}function q(e,t,r=[],m=function(){}){let o=!1;const u=new Proxy(m,{get(d,l){if(L(o),l===Ue)return()=>{ve(u),oe(e),t.clear(),o=!0};if(l==="then"){if(r.length===0)return{then:()=>u};const c=z(e,t,{type:"GET",path:r.map(f=>f.toString())}).then(M);return c.then.bind(c)}return q(e,t,[...r,l])},set(d,l,c){L(o);const[f,i]=H(c);return z(e,t,{type:"SET",path:[...r,l].map(n=>n.toString()),value:f},i).then(M)},apply(d,l,c){L(o);const f=r[r.length-1];if(f===Pe)return z(e,t,{type:"ENDPOINT"}).then(M);if(f==="bind")return q(e,t,r.slice(0,-1));const[i,n]=ee(c);return z(e,t,{type:"APPLY",path:r.map(s=>s.toString()),argumentList:i},n).then(M)},construct(d,l){L(o);const[c,f]=ee(l);return z(e,t,{type:"CONSTRUCT",path:r.map(i=>i.toString()),argumentList:c},f).then(M)}});return Ie(u,e),u}function Ce(e){return Array.prototype.concat.apply([],e)}function ee(e){const t=e.map(H);return[t.map(r=>r[0]),Ce(t.map(r=>r[1]))]}const ue=new WeakMap;function Fe(e,t){return ue.set(e,t),e}function Ae(e){return Object.assign(e,{[ne]:!0})}function H(e){for(const[t,r]of ie)if(r.canHandle(e)){const[m,o]=r.serialize(e);return[{type:"HANDLER",name:t,value:m},o]}return[{type:"RAW",value:e},ue.get(e)||[]]}function M(e){switch(e.type){case"HANDLER":return ie.get(e.name).deserialize(e.value);case"RAW":return e.value}}function z(e,t,r,m){return new Promise(o=>{const u=Math.trunc(Math.random()*Number.MAX_SAFE_INTEGER).toString();t.set(u,o),e.start&&e.start(),e.postMessage(Object.assign({id:u},r),m)})}function te(e,t,r,m,o,u){const d=t*r,l=d,c=d+d/4,f=u.byteLength/16,i=new ArrayBuffer(u.byteLength),n=new DataView(i),s=new DataView(u.buffer);for(let a=0;a<f;a++){const E=a%m,S=Math.floor(a/m),x=Math.round(E*(t/m)),I=Math.round(S*(r/o));if(x>=t||I>=r)continue;const h=I*t+x,v=Math.floor(I/2)*(t/2)+Math.floor(x/2),_=e[h]??0,p=(e[l+v]??128)-128,y=(e[c+v]??128)-128;let b=_+1.402*y,w=_-.344136*p-.714136*y,C=_+1.772*p;b=Math.min(255,Math.max(0,b)),w=Math.min(255,Math.max(0,w)),C=Math.min(255,Math.max(0,C));const P=a*16;n.setFloat32(P,s.getFloat32(P,!0),!0),n.setFloat32(P+4,s.getFloat32(P+4,!0),!0),n.setFloat32(P+8,s.getFloat32(P+8,!0),!0),n.setUint8(P+12,b),n.setUint8(P+13,w),n.setUint8(P+14,C),n.setUint8(P+15,255)}return new Uint8Array(i)}function re(e,t,r,m,o){const u=t*r,d=new Float32Array(u*3);for(let i=0;i<r;i++)for(let n=0;n<t;n++){const s=i*t+n,a=e[s]??0;let E=0,S=0,x=0;const h=a*1;if(h>0&&m!==0&&o!==0){const _=t*.5,p=r*.5;E=(n-_)*h/m,S=(i-p)*h/o,x=h}const v=s*3;d[v]=E,d[v+1]=S,d[v+2]=x}const l=new ArrayBuffer(u*16),c=new DataView(l),f=new Uint8Array(d.buffer);for(let i=0;i<u;i++){const n=i*12,s=i*16;for(let a=0;a<12;++a)c.setUint8(s+a,f[n+a]);c.setUint8(s+12,0),c.setUint8(s+13,0),c.setUint8(s+14,0),c.setUint8(s+15,255)}return new Uint8Array(l)}const le=128,Oe=16,Me=`
struct Intrinsics {
  fx: f32,
  fy: f32,
  cx: f32,
  cy: f32,
  depthScale: f32,
  depthWidth: f32,
  depthHeight: f32,
  i420Width: f32,
  i420Height: f32,
  numFrames_f: f32,
  bytesPerI420Frame_f: f32,
};

struct OutputPointData {
  x: f32,
  y: f32,
  z: f32,
  color: u32,
};

@group(0) @binding(0) var<storage, read> depthBuffer: array<u32>;
@group(0) @binding(1) var<storage, read> intrinsics: Intrinsics;
@group(0) @binding(2) var<storage, read_write> xyzColorBuffer: array<OutputPointData>;
@group(0) @binding(3) var<storage, read> i420Buffer: array<u32>;

fn getI420Byte(byteIndexWithinFrame: u32, frameOffsetElements: u32, bufferLengthElements: u32) -> u32 {
  let globalByteIndex = (frameOffsetElements * 4u) + byteIndexWithinFrame;
  let elementIndex = globalByteIndex / 4u;
  let offsetInElement = globalByteIndex % 4u;
  if (elementIndex >= bufferLengthElements) {
    return 0u;
  }
  let packedValue = i420Buffer[elementIndex];
  return (packedValue >> (offsetInElement * 8u)) & 0xFFu;
}

@compute @workgroup_size(${le}, 1, 1)
fn main(@builtin(global_invocation_id) global_id: vec3<u32>) {
  let pixel_idx_in_frame = global_id.x;
  let frame_idx = global_id.y;
  let depthWidth = u32(intrinsics.depthWidth);
  let depthHeight = u32(intrinsics.depthHeight);
  let i420WidthU = u32(intrinsics.i420Width);
  let i420HeightU = u32(intrinsics.i420Height);
  let numFrames = u32(intrinsics.numFrames_f);
  let bytesPerI420Frame = u32(intrinsics.bytesPerI420Frame_f);
  let numPixelsPerFrame = depthWidth * depthHeight;
  if (pixel_idx_in_frame >= numPixelsPerFrame || frame_idx >= numFrames || depthWidth == 0u || depthHeight == 0u) {
    return;
  }
  let global_output_idx = (frame_idx * numPixelsPerFrame) + pixel_idx_in_frame;
  let depth_elements_per_frame = (numPixelsPerFrame + 1u) / 2u;
  let depth_frame_offset = frame_idx * depth_elements_per_frame;
  let i420AlignedStrideBytes = (bytesPerI420Frame + 3u) / 4u * 4u;
  let i420_elements_per_frame_aligned = i420AlignedStrideBytes / 4u;
  let i420_frame_offset = frame_idx * i420_elements_per_frame_aligned;
  let depthIndex32_within_frame = pixel_idx_in_frame / 2u;
  let packedDepthU32_idx = depth_frame_offset + depthIndex32_within_frame;
  if (packedDepthU32_idx >= arrayLength(&depthBuffer)) {
    return;
  }
  let packedDepthU32 = depthBuffer[packedDepthU32_idx];
  var rawDepthU16: u32;
  if (pixel_idx_in_frame % 2u == 0u) {
    rawDepthU16 = packedDepthU32 & 0xFFFFu;
  } else {
    rawDepthU16 = (packedDepthU32 >> 16u) & 0xFFFFu;
  }
  let u = f32(pixel_idx_in_frame % depthWidth);
  let v = f32(pixel_idx_in_frame / depthWidth);
  var outputPoint: OutputPointData;
  outputPoint.x = 0.0;
  outputPoint.y = 0.0;
  outputPoint.z = 0.0;
  outputPoint.color = 0xFF000000u;
  let fx = intrinsics.fx;
  let fy = intrinsics.fy;
  let depthScale = intrinsics.depthScale;
  if (rawDepthU16 > 0u && fx != 0.0 && fy != 0.0 && depthScale > 0.0) {
    let z = f32(rawDepthU16) * depthScale;
    let imageCenterX = f32(depthWidth) * 0.5;
    let imageCenterY = f32(depthHeight) * 0.5;
    outputPoint.x = (u - imageCenterX) * z / fx;
    outputPoint.y = (v - imageCenterY) * z / fy;
    outputPoint.z = z;
    if (i420WidthU > 0u && i420HeightU > 0u && bytesPerI420Frame > 0u) {
      let i420X = min(i420WidthU - 1u, u32(floor(u * (intrinsics.i420Width / intrinsics.depthWidth))));
      let i420Y = min(i420HeightU - 1u, u32(floor(v * (intrinsics.i420Height / intrinsics.depthHeight))));
      let frameSizeY = i420WidthU * i420HeightU;
      let uvWidth = (i420WidthU + 1u) / 2u;
      let uvHeight = (i420HeightU + 1u) / 2u;
      let frameSizeUV = uvWidth * uvHeight;
      let uOffsetBytes = frameSizeY;
      let vOffsetBytes = frameSizeY + frameSizeUV;
      let yIndexBytes = i420Y * i420WidthU + i420X;
      let uvX = i420X / 2u;
      let uvY = i420Y / 2u;
      let uvIndexBytes = uvY * uvWidth + uvX;
      let uIndexBytes = uOffsetBytes + uvIndexBytes;
      let vIndexBytes = vOffsetBytes + uvIndexBytes;
      let i420BufferTotalElements = arrayLength(&i420Buffer);
      if (yIndexBytes < bytesPerI420Frame && uIndexBytes < bytesPerI420Frame && vIndexBytes < bytesPerI420Frame && (i420_frame_offset + (vIndexBytes / 4u)) < i420BufferTotalElements) {
        let y_byte = getI420Byte(yIndexBytes, i420_frame_offset, i420BufferTotalElements);
        let u_byte = getI420Byte(uIndexBytes, i420_frame_offset, i420BufferTotalElements);
        let v_byte = getI420Byte(vIndexBytes, i420_frame_offset, i420BufferTotalElements);
        let y_f = f32(y_byte);
        let u_f = f32(u_byte) - 128.0;
        let v_f = f32(v_byte) - 128.0;
        var r_f = y_f + 1.402 * v_f;
        var g_f = y_f - 0.344136 * u_f - 0.714136 * v_f;
        var b_f = y_f + 1.772 * u_f;
        let r = u32(clamp(r_f, 0.0, 255.0)) & 0xFFu;
        let g = u32(clamp(g_f, 0.0, 255.0)) & 0xFFu;
        let b = u32(clamp(b_f, 0.0, 255.0)) & 0xFFu;
        let a = 255u;
        outputPoint.color = (r) | (g << 8u) | (b << 16u) | (a << 24u);
      }
    }
  }
  if (global_output_idx < arrayLength(&xyzColorBuffer)) {
    xyzColorBuffer[global_output_idx] = outputPoint;
  }
}

`;async function Te(e,t,r,m,o,u,d,l,c,f,{hasGPU:i}){var v;const n=e.length;if(n===0||n!==l.length)return console.warn("GPU: Input frame arrays are empty or mismatched."),[];if(t<=0||r<=0)throw new Error("GPU: Invalid depth dimensions!");if(e[0]&&!(e[0]instanceof Uint16Array))throw new Error("GPU: depthFrames[0].data is NOT a Uint16Array!");if(l[0]&&!(l[0]instanceof Uint8Array))throw new Error("GPU: i420Frames[0].data is NOT a Uint8Array!");const s=1;if(!i){const _=[];for(let p=0;p<n;p++){const y=e[p],b=l[p];if(!y||!b){console.warn(`CPU Fallback: Skipping frame ${p} due to missing data.`),_.push(new Uint8Array(0));continue}try{const w=re(y,t,r,m,o);_.push(te(b,c,f,t,r,w))}catch(w){console.error(`CPU Fallback: Error processing frame ${p}:`,w),_.push(new Uint8Array(0))}}return _}let a=null,E=null,S=null,x=null,I=null,h=null;try{const _=await navigator.gpu.requestAdapter();if(!_)throw new Error("Failed to get GPU adapter.");a=await _.requestDevice();const p=a.queue,y=t*r,b=y*Oe,w=b*n,C=y*2,P=Math.ceil(C/4),fe=P*n*4,k=((v=l[0])==null?void 0:v.byteLength)??0;if(k===0&&n>0)throw new Error("GPU: I420 frame data is empty or invalid for size calculation.");const G=Math.ceil(k/4)*4,ce=G*n,D=new Float32Array([m,o,u,d,s,t,r,c,f,n,k]),de=Math.max(D.byteLength,64);S=a.createBuffer({label:"Intrinsics Buffer",size:de,usage:GPUBufferUsage.STORAGE|GPUBufferUsage.COPY_DST}),p.writeBuffer(S,0,D.buffer,D.byteOffset,D.byteLength),E=a.createBuffer({label:"Depth Buffer (Combined)",size:fe,usage:GPUBufferUsage.STORAGE|GPUBufferUsage.COPY_DST,mappedAtCreation:!0});const me=E.getMappedRange(),T=new Uint32Array(me);for(let g=0;g<n;++g){const U=e[g];if(!U||!(U instanceof Uint16Array)){console.warn(`GPU: Skipping depth frame ${g} due to missing/invalid data.`);const B=g*P,A=P;T.fill(0,B,B+A);continue}const F=g*P;for(let B=0;B<y;B++){const A=U[B]??0,O=F+Math.floor(B/2);if(O>=T.length)continue;B%2===0?T[O]=T[O]&4294901760|A:T[O]=T[O]&65535|A<<16}}E.unmap(),x=a.createBuffer({label:"I420 Buffer (Combined, Aligned)",size:ce,usage:GPUBufferUsage.STORAGE|GPUBufferUsage.COPY_DST,mappedAtCreation:!0});const Z=x.getMappedRange(),K=new Uint8Array(Z);for(let g=0;g<n;++g){const U=l[g],F=g*G;if(!U||!(U instanceof Uint8Array)||U.byteLength!==k){console.warn(`GPU: Skipping I420 frame ${g} due to missing/invalid data or size mismatch.`),K.fill(0,F,F+G);continue}if(new Uint8Array(Z,F,U.byteLength).set(U),G>U.byteLength){const A=F+U.byteLength,O=G-U.byteLength;K.fill(0,A,A+O)}}x.unmap(),I=a.createBuffer({label:"Output XYZColor Buffer (Combined)",size:w,usage:GPUBufferUsage.STORAGE|GPUBufferUsage.COPY_SRC}),h=a.createBuffer({label:"Readback Buffer",size:w,usage:GPUBufferUsage.COPY_DST|GPUBufferUsage.MAP_READ});const J=a.createBindGroupLayout({label:"Compute Bind Group Layout",entries:[{binding:0,visibility:GPUShaderStage.COMPUTE,buffer:{type:"read-only-storage"}},{binding:1,visibility:GPUShaderStage.COMPUTE,buffer:{type:"read-only-storage"}},{binding:2,visibility:GPUShaderStage.COMPUTE,buffer:{type:"storage"}},{binding:3,visibility:GPUShaderStage.COMPUTE,buffer:{type:"read-only-storage"}}]}),pe=a.createBindGroup({label:"Compute Bind Group",layout:J,entries:[{binding:0,resource:{buffer:E}},{binding:1,resource:{buffer:S}},{binding:2,resource:{buffer:I}},{binding:3,resource:{buffer:x}}]}),ye=a.createShaderModule({label:"Compute Shader Module",code:Me}),ge=a.createComputePipeline({label:"Compute Pipeline",layout:a.createPipelineLayout({bindGroupLayouts:[J]}),compute:{module:ye,entryPoint:"main"}}),X=a.createCommandEncoder({label:"Compute Command Encoder"}),R=X.beginComputePass({label:"Compute Pass"});R.setPipeline(ge),R.setBindGroup(0,pe);const he=Math.ceil(y/le),be=n;R.dispatchWorkgroups(he,be,1),R.end(),X.copyBufferToBuffer(I,0,h,0,w),p.submit([X.finish()]),await h.mapAsync(GPUMapMode.READ);const _e=h.getMappedRange(),Q=new Uint8Array(_e.slice(0));h.unmap(),h=null;const N=[];for(let g=0;g<n;g++){const U=g*b,F=Math.min(U+b,Q.byteLength),B=Q.slice(U,F);B.byteLength!==b?(console.warn(`GPU: Result frame ${g} has incorrect size (${B.byteLength} vs ${b}). Padding or error occurred.`),N.push(new Uint8Array(b))):N.push(B)}return N}catch(_){console.error("GPU: Error during WebGPU processing:",_),console.warn("GPU: Falling back to CPU due to error.");const p=[];for(let y=0;y<n;y++){const b=e[y],w=l[y];if(!b||!w){console.warn(`CPU Fallback (error path): Skipping frame ${y} due to missing data.`),p.push(new Uint8Array(0));continue}try{const C=re(b,t,r,m,o);p.push(te(w,c,f,t,r,C))}catch(C){console.error(`CPU Fallback (error path): Error processing frame ${y}:`,C),p.push(new Uint8Array(0))}}return p}finally{E==null||E.destroy(),S==null||S.destroy(),x==null||x.destroy(),I==null||I.destroy(),h==null||h.destroy()}}j({depthToPointcloudGPU:Te});
