/* eslint-disable */
import type { FunctionComponent } from 'react'
import type { ContainerProperties } from '../patterns/container.d.mts';
import type { HTMLStyledProps } from '../types/jsx.d.mts';
import type { DistributiveOmit } from '../types/system-types.d.mts';

export interface ContainerProps extends ContainerProperties, DistributiveOmit<HTMLStyledProps<'div'>, keyof ContainerProperties > {}


export declare const Container: FunctionComponent<ContainerProps>