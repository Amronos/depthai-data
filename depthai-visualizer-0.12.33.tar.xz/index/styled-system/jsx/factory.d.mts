/* eslint-disable */
import type { Styled } from '../types/jsx.d.mts';
export declare const styled: Styled