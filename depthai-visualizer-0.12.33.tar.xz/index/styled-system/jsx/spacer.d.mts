/* eslint-disable */
import type { FunctionComponent } from 'react'
import type { SpacerProperties } from '../patterns/spacer.d.mts';
import type { HTMLStyledProps } from '../types/jsx.d.mts';
import type { DistributiveOmit } from '../types/system-types.d.mts';

export interface SpacerProps extends SpacerProperties, DistributiveOmit<HTMLStyledProps<'div'>, keyof SpacerProperties > {}


export declare const Spacer: FunctionComponent<SpacerProps>