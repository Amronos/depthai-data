/* eslint-disable */
import type { FunctionComponent } from 'react'
import type { CircleProperties } from '../patterns/circle.d.mts';
import type { HTMLStyledProps } from '../types/jsx.d.mts';
import type { DistributiveOmit } from '../types/system-types.d.mts';

export interface CircleProps extends CircleProperties, DistributiveOmit<HTMLStyledProps<'div'>, keyof CircleProperties > {}


export declare const Circle: FunctionComponent<CircleProps>