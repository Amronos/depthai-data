/* eslint-disable */
import type { ConditionalValue } from '../types/index.d.mts';
import type { DistributiveOmit, Pretty } from '../types/system-types.d.mts';

interface TableHeaderVariant {
  
}

type TableHeaderVariantMap = {
  [key in keyof TableHeaderVariant]: Array<TableHeaderVariant[key]>
}

export type TableHeaderVariantProps = {
  [key in keyof TableHeaderVariant]?: ConditionalValue<TableHeaderVariant[key]> | undefined
}

export interface TableHeaderRecipe {
  __type: TableHeaderVariantProps
  (props?: TableHeaderVariantProps): string
  raw: (props?: TableHeaderVariantProps) => TableHeaderVariantProps
  variantMap: TableHeaderVariantMap
  variantKeys: Array<keyof TableHeaderVariant>
  splitVariantProps<Props extends TableHeaderVariantProps>(props: Props): [TableHeaderVariantProps, Pretty<DistributiveOmit<Props, keyof TableHeaderVariantProps>>]
}

/** Styles for the TableHeader component */
export declare const tableHeader: TableHeaderRecipe